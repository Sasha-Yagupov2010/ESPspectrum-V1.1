#ifndef SnakeGame_h
#define SnakeGame_h
#include <Arduino.h>
// код библиотеки


void snake_game()
{
 int resx = 270;
 int resy = 235; 
 int snakeX = 100;
 int snakeY = 150;
 int appleX, appleY; 

 bool ex = false;
 
 bool ap = true;
 int fps = 30;
 int fpsdel = 1000 / fps;

 int score = 0;
 int score2 = score;
 int st = 10;
 int setT = 25000;
 int t = 25000;
 vga.setFont(Font6x8);
 //settings ^
 
while(1)
{ 
  //arena  
 vga.rect( 5, 5, resx, resy, vga.RGB(255, 255, 255) );
 vga.setCursor(resx + 10, 5);
 vga.println("Snake");
 vga.setCursor(resx + 10, 17);
 vga.println("Score");
 vga.println(score);
 vga.setCursor(resx + 10, 37);
 vga.println("time");
 vga.println(setT);


 //snake
 vga.setTextColor(vga.RGB(0,255,0));
 vga.setCursor(snakeX, snakeY);
 vga.print("[]");
 vga.setTextColor(vga.RGB(255,255,255));
 
//apple
if(ap == true){
 appleX = random(10, resx - 5);
 appleY = random(10, resy - 5);
 ap = false;
}
 vga.fillCircle(appleX, appleY, 4, vga.RGB(255,0,0));
 

//toch
if(snakeX - appleX <=10 and snakeX - appleX >= 0 or appleX - snakeX <= 10 and appleX - snakeX >= 0 ) {
  if(snakeY - appleY <= 10 and snakeY - appleY >= 0 or appleY - snakeY <= 10 and appleY - snakeY >=0){ap = true; score += 1;}
}

//exit if toch
if(snakeX > resx or snakeX < 0){
vga.setFont(CodePage437_8x16); vga.setCursor(resx / 2, resy / 2); 
vga.print("GAME OVER"); delay(4000);
vga.clear(vga.RGB(0, 0, 0));vga.setCursor(0, 0);
vga.setFont(CodePage437_8x14); return; }

if(snakeY > resy or snakeY < 0){
vga.setFont(CodePage437_8x16); vga.setCursor(resx / 2, resy / 2); 
vga.print("GAME OVER"); delay(4000); 
vga.clear(vga.RGB(0, 0, 0));vga.setCursor(0, 0); 
vga.setFont(CodePage437_8x14); return;}



if(setT < 1){
vga.setFont(CodePage437_8x16); vga.setCursor(resx / 2, resy / 2); 
vga.print("GAME OVER"); delay(4000); 
vga.clear(vga.RGB(0, 0, 0));vga.setCursor(0, 0); 
vga.setFont(CodePage437_8x14); setT = 0; return;}

if(score != score2){ t = t - 1000; setT = t; score2 = score;}

/*==========================================================*/  
 
  int scanval = 0;
  for(int i = 0; i<11; i++)
  {
    while(digitalRead(CLOCK));
    scanval |= digitalRead(DATA) << i;
    while(!digitalRead(CLOCK));
  }
  scanval >>= 1;
  scanval &= 0xFF;
  if(lastscan != 0xF0 && scanval != 0xF0)
 {
        //системные клавиши, чтобы не было напечатано непонятных символов             
          if(scanval == 0xE0){vga.clear(vga.RGB(0, 0, 0));vga.setCursor(0, 0); vga.setFont(CodePage437_8x14); return;}
          if(scanval == 0x1D){snakeY -= st;}
          if(scanval == 0x1B){snakeY += st;}
          if(scanval == 0x1C){snakeX -= st;}
          if(scanval == 0x23){snakeX += st;}
   }
  lastscan = scanval;
/*==========================================================*/  

 score2 = score;
 delay(fpsdel);
 if(setT > fpsdel - fpsdel/2){ setT -= fpsdel; } 
 vga.clear(0);
}
 
}
#endif