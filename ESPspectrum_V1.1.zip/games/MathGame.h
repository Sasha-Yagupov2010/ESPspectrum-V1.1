#ifndef MathGame_h
#define MathGame_h
#include <Arduino.h>
// код игровой библиотеки


void math_game()
{
 const int resx = 315;
 const int resy = 235; 

 int fps = 50;
 int fpsdel = 1000 / fps;

 String pr = " ";
 int answ = 0;
 int trueAnsw = 0;
 int score = 0;

 int ex = 0;
 //vga.setFont(Font6x8);
 //settings ^
 
vga.clear(0);
vga.setCursor(resx/2,resy/2);
vga.print("5"); delay(1000); vga.clear(0);
vga.setCursor(resx/2,resy/2);
vga.print("4"); delay(1000); vga.clear(0);
vga.setCursor(resx/2,resy/2);
vga.print("3"); delay(1000); vga.clear(0);
vga.setCursor(resx/2,resy/2);
vga.print("2"); delay(1000); vga.clear(0);
vga.setCursor(resx/2,resy/2);
vga.print("1"); delay(1000); vga.clear(0);
 unsigned long Time = millis(); //sek
int a;
int b;
int r;
while(1)
{ 
  String str = "";
  //arena  
 vga.rect( 0, 0, resx, resy, vga.RGB(255, 255, 255) );
 vga.setCursor(5, 10);
 vga.print("Score ");
 vga.println(score);


/*========================================================== */
if(trueAnsw == 0){ //генерация случаного примера
r = random(1,4);
// 1   +
// 2   -
// 3   *
if(r == 1){
   a = random(5,299);
   b = random(5,299);
  trueAnsw = a + b;
}
 if(r == 2){
   a = random(5,399);
   b = random(4,299);
  trueAnsw = a - b;
} 
if(r == 3){
   a = random(5,220);
   b = random(2,30);
  trueAnsw = a * b;
}

}

if(trueAnsw != 0){
vga.setCursor(resx/2 - 20, resy/2);
if(r == 1){ vga.print(a); vga.print(" + "); vga.print(b); }
if(r == 2){ vga.print(a); vga.print(" - "); vga.print(b); } 
if(r == 3){ vga.print(a); vga.print(" * "); vga.print(b); }

}

/*==========================================================*/
vga.setCursor(resx/2, resy/2 + resy/4);
while(answ == 0){
 int scanval = 0;
  for(int i = 0; i<11; i++)
  {
    while(digitalRead(CLOCK));
    scanval |= digitalRead(DATA) << i;
    while(!digitalRead(CLOCK));
  }
  scanval >>= 1;
  scanval &= 0xFF;
  Serial.println(scanval, HEX);
  if(lastscan != 0xF0 && scanval != 0xF0)
 {
  if(scanval != 0x5A and scanval != 0xE0)
    {
   str = str + keymap[scanval];   
   Serial.println(keymap[scanval]);
   vga.print(keymap[scanval]);
     }     
          //if(scanval == 0x76){vga.clear(vga.RGB(0,0,0)); vga.setCursor(0, 0); str = ""; }
                    
           if(scanval == 0x5A){ 
            vga.setCursor(0, 0); 
            vga.clear(vga.RGB(0,0,0)); 
            answ = str.toInt();
            str = "";
            }
          
          if(scanval == 0xE0){vga.clear(vga.RGB(0,0,0)); vga.setCursor(0, 0); str = ""; ex = 1; answ = 1;}
      
  }
  lastscan = scanval;
}

/*==========================================================  */
if(ex == 1){delay(100); vga.setCursor(resx/2 - 10, resy/2); vga.print(millis() - Time);
vga.print(" ms "); delay(2000); vga.clear(0); vga.setCursor(0,0);  return;}

if(answ != 0){
  if(answ == trueAnsw){score += 1; answ = 0; trueAnsw = 0;} //правильность ответа
  else{answ = 0; trueAnsw = 0; if(score>0){score -= 1;}}
}
if(score<0){score = 0;} //если каким то чудом < 0 то делаем равным 0 


 delay(fpsdel);
 vga.clear(0); 
 vga.setCursor(0,0);
}
 
}

#endif 